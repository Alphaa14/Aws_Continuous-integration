var msg = 'Hello World';
console.log(msg);